$(window).load(function() {
    $.ajax({
        url: mp_ajax,
        type: "get",
        dataType: 'json',
        data: {
            'configurationvaluepicker':''
        },
        cache: false,
        success: function(data) {
            if(!Object.entries(data).length == 0){
                cursorTrail({
                    pattern: data.shap,
                    animationType: (data.animation != '') ? data.animation : 'flash'
                });
            }
        },
        error: function(error) {
            console.log('***************************');
            console.log('*****Errors******:'+error);
        }
    });
});
