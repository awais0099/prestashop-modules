<?php
/**
 * SeoAltImages
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @author    FMM Modules
 * @copyright Copyright 2021 © FMM Modules
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 * @category  FMM Modules
 * @package   SeoAltImages
*/

if (!defined('_PS_VERSION_')) {
	exit;
}
if (!defined('_MYSQL_ENGINE_')) {
	define('_MYSQL_ENGINE_', 'MyISAM'); 
}

class ExtraOrderColumns extends Module {

	public function __construct()
	{
		$this->name = 'extraordercolumns';
		$this->tab = 'front_office_feature';
		$this->version = '1.0.0';
		$this->author = 'FMM Modules';
		$this->displayName = $this->l('Order Grid Field Addition');
		$this->description = $this->l('Add field to order grid table.');
		$this->module_key = 'zzxxxzzzxxxxzzz';
		$this->bootstrap = true;
		$this->author_address = '0xcC5e76A6182fa47eD831E43d80Cd0985a14BB095';
		parent::__construct();
	}

	public function install()
	{
		if (Tools::version_compare(_PS_VERSION_, '1.7.7.1', '>=')) {
			return parent::install()
			&& $this->registerHook('actionAdminOrdersListingFieldsModifier')
			&& $this->registerHook('actionAdminControllerSetMedia')
			&& $this->registerHook('actionOrderGridDefinitionModifier')
			&& $this->registerHook('actionOrderGridQueryBuilderModifier')
			&& $this->registerHook('actionAdminOrdersListingResultsModifier');
		} else {
			$this->_errors[] = $this->l('The version of prestashop should be 1.7.7.1 or greater');

            return false;
		}
	}
	
	public function hookActionAdminControllerSetMedia()
    {
        $this->context->controller->addCSS($this->_path.'views/css/bo_'.$this->name.'.css');
    }
	
	public function uninstall()
	{
		if (!parent::uninstall()) {
			return false;
		}

		Configuration::deleteByName('FMM_AH_ORDERGRIDLANGFIELD_COLUMNS');

		$this->unregisterHook('actionAdminOrdersListingFieldsModifier');
		$this->unregisterHook('actionAdminControllerSetMedia');
		$this->unregisterHook('actionOrderGridDefinitionModifier');
		$this->unregisterHook('actionOrderGridQueryBuilderModifier');
		$this->unregisterHook('actionAdminOrdersListingResultsModifier');
		return true;
	}

	public function renderConfigurationForm()
    {
        $default_lang = (int) Configuration::get('PS_LANG_DEFAULT');

        $form = [
            'form' => [
                'tinymce' => true,
                'legend' => [
                    'title' => $this->l('Settings'),
                ],
                'input' => [
                    array(
						'type'    => 'checkbox',                   
						'label'   => $this->l('Select columns'),      
						'desc'    => $this->l('Select columns you wants to add in order table.'),  
						'name'    => 'columns_to_be_added[]',
						'values'  => array(
							'id'    => 'id_option',                  
							'name'  => 'name',                       
							'query' => array(
								array(
									'id_option' => 'lang',
									'name' => $this->l('lang'),
									'val' => 'lang',
								),array(
									'id_option' => 'gift',
									'name' => $this->l('Gift'),
									'val' => 'gift',
								),array(
									'id_option' => 'currency',
									'name' => $this->l('Currency'),
									'val' => 'currency'
								),array(
									'id_option' => 'delivery_number',
									'name' => $this->l('Delivery Number'),
									'val' => 'delivery_number'
								),array(
									'id_option' => 5,
									'name' => $this->l('Total Shipping'),
									'val' => 'total_shipping'
								),array(
									'id_option' => 'total_discounts',
									'name' => $this->l('Total Discounts'),
									'val' => 'total_discounts'
								),array(
									'id_option' => 'total_discounts_tax_incl',
									'name' => $this->l('Total Discounts Tax Incl'),
									'val' => 'total_discounts_tax_incl'
								),array(
									'id_option' => 'total_discounts_tax_excl',
									'name' => $this->l('Total Discounts TaxExcl'),
									'val' => 'total_discounts_tax_excl'
								),
							),                     
						)
					)
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        // Module, token and currentIndex
        $helper->module = $this;
        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);

        // Default language
        $helper->default_form_language = $default_lang;

        $helper->allow_employee_form_lang = $default_lang;

        $helper->title = $this->displayName;
        
        $helper->submit_action = 'submitConfigurationForm';

        foreach (explode(' ', Configuration::get('FMM_AH_ORDERGRIDLANGFIELD_COLUMNS')) as $value) {
        	$helper->fields_value['columns_to_be_added[]_'.$value] = true;
        }
        return $helper->generateForm([$form]);
    }

    public function __postProcess()
    {
        $output = '';

        if (Tools::isSubmit('submitConfigurationForm')) {
            Configuration::updateValue(
                'FMM_AH_ORDERGRIDLANGFIELD_COLUMNS',
                implode(' ', Tools::getValue('columns_to_be_added'))
            );
            $output = $this->displayConfirmation($this->l('Setting updated'));
        }
        return $output . $this->renderConfigurationForm();
    }

    public function getContent()
    {
        return $this->__postProcess();
    }
	
	public function hookActionOrderGridDefinitionModifier($list)
    {
    	if (Configuration::get('FMM_AH_ORDERGRIDLANGFIELD_COLUMNS') != '') {
    		$mycos = explode(" ",Configuration::get('FMM_AH_ORDERGRIDLANGFIELD_COLUMNS'));
    		$definition = $list['definition'];
	    	$columns = $definition->getColumns();
    		
    		// dump($columns);

    		foreach ($mycos as $value) {
    			$columns->addAfter(
					'payment',
					(new PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn($value))
						->setName($this->l(Tools::toCamelCase($value)))
						->setOptions([
							'field' => $value,
						])
				);
    		}
    		$columns->remove('company');
    	}
    }
	
	public function hookActionOrderGridQueryBuilderModifier(array $params)
    {
        /** @var QueryBuilder $searchQueryBuilder */
        if (Configuration::get('FMM_AH_ORDERGRIDLANGFIELD_COLUMNS') != '') {

	        $searchQueryBuilder = $params['search_query_builder'];


	        $mycos = explode(" ",Configuration::get('FMM_AH_ORDERGRIDLANGFIELD_COLUMNS'));
	  		
	  		$searchQueryBuilder->leftJoin(
	            'o',
	            '`' . pSQL(_DB_PREFIX_) . 'lang`',
	            'la',
	            'la.`id_lang` = o.`id_lang`'
	        );

	        // dump($searchQueryBuilder->select('cur.iso_code'));exit;

	        foreach ($mycos as $value) {
	        	if ($value === 'currency') {
	        		$searchQueryBuilder->addSelect('cur.iso_code AS '.$value);
	        	} elseif ($value === 'lang') {
	        		$searchQueryBuilder->addSelect('la.`iso_code` AS '.$value);
	        	}  elseif ($value == 'total_shipping') {
	       			$searchQueryBuilder->addSelect('o.'.$value.' AS '.$value);
	        	} else {
	        		$searchQueryBuilder->addSelect('o.'.$value.' AS '.$value);
	        	}
	        }
        }
    }
	
	public function hookActionAdminOrdersListingResultsModifier($list)
    {
		// dump($list);exit;
		//$list['id_lang'] = '';
	}
	
//	public function hookActionAdminOrdersListingFieldsModifier($list)
//    {
//		$customFields['lang'] = array(
//                    'title' => 'Language',
//                    'field_type' => 'text',
//                    'orderby'   => false,
//                    'search'   => false,
//                    'remove_onclick' => true,
//                );
//		$list['fields'] = array_merge($list['fields'], $customFields);
//	}
}
