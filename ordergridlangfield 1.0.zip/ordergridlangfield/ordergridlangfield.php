<?php
/**
 * SeoAltImages
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @author    FMM Modules
 * @copyright Copyright 2021 © FMM Modules
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 * @category  FMM Modules
 * @package   SeoAltImages
*/

if (!defined('_PS_VERSION_')) {
	exit;
}
if (!defined('_MYSQL_ENGINE_')) {
	define('_MYSQL_ENGINE_', 'MyISAM'); 
}

class OrderGridLangField extends Module {

	public function __construct()
	{
		$this->name = 'ordergridlangfield';
		$this->tab = 'front_office_features';
		$this->version = '1.0.0';
		$this->author = 'FMM Modules';
		$this->displayName = $this->l('Order Grid Field Addition');
		$this->description = $this->l('Add Language field to order grid table.');
		$this->module_key = 'zzxxxzzzxxxxzzz';
		$this->bootstrap = true;
		$this->author_address = '0xcC5e76A6182fa47eD831E43d80Cd0985a14BB095';
		parent::__construct();
	}

	public function install()
	{
		return parent::install()
		&& $this->registerHook('actionAdminOrdersListingFieldsModifier')
		&& $this->registerHook('actionAdminControllerSetMedia')
		&& $this->registerHook('actionOrderGridDefinitionModifier')
		&& $this->registerHook('actionOrderGridQueryBuilderModifier')
		&& $this->registerHook('actionAdminOrdersListingResultsModifier');
	}
	
	public function hookActionAdminControllerSetMedia()
    {
        $this->context->controller->addCSS($this->_path.'views/css/bo_'.$this->name.'.css');
    }
	
	public function uninstall()
	{
		if (!parent::uninstall()) {
			return false;
		}
		return true;
	}
	
	public function hookActionOrderGridDefinitionModifier($list)
    {
		$list['definition']
		->getColumns()
		->addAfter(
			'payment',
			(new PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn('lang'))
				->setName($this->l('Lang'))
				->setOptions([
					'field' => 'lang',
					 'clickable' => true,
					 'sortable' => true
				])
		)->remove('company');
    }
	
	public function hookActionOrderGridQueryBuilderModifier(array $params)
    {
        /** @var QueryBuilder $searchQueryBuilder */
        
        $searchQueryBuilder = $params['search_query_builder'];
		
		$searchQueryBuilder->leftJoin(
            'o',
            '`' . pSQL(_DB_PREFIX_) . 'lang`',
            'la',
            'la.`id_lang` = o.`id_lang`'
        );
		//dump($searchQueryBuilder);exit;
		$searchQueryBuilder->addSelect(
            'la.`iso_code` AS lang'
        );
    }
	
	public function hookActionAdminOrdersListingResultsModifier($list)
    {
		//dump($list);exit;
		//$list['id_lang'] = '';
	}
	
//	public function hookActionAdminOrdersListingFieldsModifier($list)
//    {
//		$customFields['lang'] = array(
//                    'title' => 'Language',
//                    'field_type' => 'text',
//                    'orderby'   => false,
//                    'search'   => false,
//                    'remove_onclick' => true,
//                );
//		$list['fields'] = array_merge($list['fields'], $customFields);
//	}
}
