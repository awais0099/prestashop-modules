<?php
/**
* DISCLAIMER
*
* Do not edit or add to this file.
* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by FME Modules.
*
* @author FMM Modules
* @copyright FMM Modules 2021
* @license Single domain
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class CursorEffect extends Module
{
    public function __construct()
    {
        $this->name = 'cursoreffect';
        $this->tab = 'back_office_feature';
        $this->version = '1.0.0';
        $this->author = 'FMM Modules';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => '1.7.99',
        ];

        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Cursor Effects');

        $this->description = $this->l('Cursor Effects');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        Configuration::updateValue('CURSOREFFECT_SHAP', '');
        return (
            parent::install()
            && $this->registerHook('displayBackOfficeHeader')
        );
    }

    public function uninstall()
    {
        Configuration::deleteByName('CURSOREFFECT_SHAP');
        return (
            parent::uninstall()
            && $this->unregisterHook('displayBackOfficeHeader')
        );
    }

    public function renderConfigurationForm()
    {
        $default_lang = (int) Configuration::get('PS_LANG_DEFAULT');
        
        $form = [
            'form' => [
                'tinymce' => true,
                'legend' => [
                    'title' => $this->l('Settings'),
                ],
                'input' => [
                    array(
                        'type' => 'radio',
                        'label'     => $this->l('Select Shap'),
                        'name'      => 'cursor_shap',
                        'required'  => true,
                        'is_bool'   => true,
                        'values' => array(
                            array(
                                'id'    => 'active_none',
                                'value' => '',
                                'label' => $this->l('None')
                            ),
                            array(
                                'id'    => 'active_goldSparkles',
                                'value' => 'goldSparkles',
                                'label' => $this->l('Gold Sparkles')
                            ),
                            array(
                                'id'    => 'active_silverSparkles',
                                'value' => 'silverSparkles',
                                'label' => $this->l('Silver Sparkles')
                            ),
                            array(
                                'id'    => 'active_colorSparkles',
                                'value' => 'colorSparkles',
                                'label' => $this->l('Color Sparkles')
                            ),
                            array(
                                'id'    => 'active_blueSparkles',
                                'value' => 'blueSparkles',
                                'label' => $this->l('Blue Sparkles')
                            ),
                            array(
                                'id'    => 'active_glitter',
                                'value' => 'glitter',
                                'label' => $this->l('Glitter')
                            ),
                            array(
                                'id'    => 'active_colorGlitter',
                                'value' => 'colorGlitter',
                                'label' => $this->l('Color Glitter')
                            ),
                            array(
                                'id' => 'active_goldStars',
                                'value' => 'goldStars',
                                'label' => $this->l('Gold Stars')
                            ),
                            array(
                                'id' => 'active_silverStars',
                                'value' => 'silverStars',
                                'label' => $this->l('Silver Stars')
                            ),
                            array(
                                'id' => 'active_colorStars',
                                'value' => 'colorStars',
                                'label' => $this->l('Color Stars')
                            ),
                            array(
                                'id' => 'active_blueStars',
                                'value' => 'blueStars',
                                'label' => $this->l('Blue Stars')
                            ),
                            array(
                                'id' => 'active_blueStars2',
                                'value' => 'blueStars2',
                                'label' => $this->l('Blue Stars 2')
                            ),
                            array(
                                'id' => 'active_goldStars2',
                                'value' => 'goldStars2',
                                'label' => $this->l('Gold Stars 2')
                            ),
                        )
                    ),
                    array(
                        'type' => 'radio',
                        'label'     => $this->l('Animation Type'),
                        'name'      => 'cursor_animation_type',
                        'required'  => true,
                        'is_bool'   => true,
                        'values' => array(
                            array(
                                'id'    => 'active_flash',
                                'value' => 'flash',
                                'label' => $this->l('Flash')
                            ),
                            array(
                                'id'    => 'active_rotation',
                                'value' => 'rotation',
                                'label' => $this->l('Rotation')
                            ),
                            array(
                                'id'    => 'active_leftDown',
                                'value' => 'leftDown',
                                'label' => $this->l('Left Down')
                            ),
                            array(
                                'id'    => 'active_rightDown',
                                'value' => 'rightDown',
                                'label' => $this->l('Right Down')
                            ),
                            array(
                                'id'    => 'active_shake',
                                'value' => 'shake',
                                'label' => $this->l('Shake')
                            ),
                            array(
                                'id'    => 'active_swing',
                                'value' => 'swing',
                                'label' => $this->l('Swing')
                            ),
                            array(
                                'id'    => 'active_down',
                                'value' => 'down',
                                'label' => $this->l('Down')
                            ),
                            array(
                                'id'    => 'active_up',
                                'value' => 'up',
                                'label' => $this->l('Up')
                            ),
                        )
                    ),
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        
        $helper->module = $this;

        $helper->title = $this->displayName;
        
        $helper->name_controller = $this->name;
        
        $helper->toolbar_scroll = true;
        
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);
        
        $helper->default_form_language = $default_lang;

        $helper->allow_employee_form_lang = $default_lang;

        $helper->toolbar_scroll = true;

        $helper->fields_value['cursor_shap'] = Tools::getValue(
            'cursor_shap', 
            Configuration::get('CURSOREFFECT_SHAP')
        );

        $helper->fields_value['cursor_animation_type'] = Tools::getValue(
            'cursor_animation_type', 
            Configuration::get('CURSOREFFECT_ANIMATION_TYPE')
        );
     
        $helper->submit_action = 'cursoreffect';

        return $helper->generateForm([$form]);
    }

    public function __postProcess()
    {
        $output = '';

        if (Tools::isSubmit('cursoreffect')) {
            Configuration::updateValue('CURSOREFFECT_SHAP', Tools::getValue('cursor_shap'));
            Configuration::updateValue('CURSOREFFECT_ANIMATION_TYPE', Tools::getValue('cursor_shap'));
            $output = $this->displayConfirmation('Setting updated');
        }

        return $output . $this->renderConfigurationForm();
    }

    public function getContent()
    {
        if (Tools::getIsset('getdata')) {
            return $this->getConfigurationData();
        }
        return $this->__postProcess();
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        Media::addJsDef(array(
            'mp_ajax' => $this->_path.'utility/cursoreffect.php'
        ));

        return '<script src="'.$this->_path.'js/cursor-trail.min.js"></script>'.'<script src="'.$this->_path.'js/cursoreffect.js"></script>';
    }
}
