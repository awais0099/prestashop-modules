<?php

include('../../../config/config.inc.php');

include('../../../init.php');

if (Tools::getIsset('configurationvaluepicker')) {
    $shap = Configuration::get('CURSOREFFECT_SHAP');
    $animation = Configuration::get('CURSOREFFECT_ANIMATION_TYPE');
    if ($shap == '') {
        echo json_encode([]);
    } else {
        echo json_encode(['shap' => $shap, 'animation' => $animation]);
    }
}
