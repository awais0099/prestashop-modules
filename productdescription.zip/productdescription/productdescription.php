<?php
/**
* DISCLAIMER
*
* Do not edit or add to this file.
* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by FME Modules.
*
* @author FMM Modules
* @copyright FMM Modules 2021
* @license Single domain
*/

if (!defined('_PS_VERSION_')) {
    exit;
}
class ProductDescription extends Module
{
    public function __construct()
    {
        $this->name = 'productdescription';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'FMM Modules';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => '1.7.99',
        ];
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('Product Description on Listing');
        $this->description = $this->l('Product description on listing');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        Configuration::updateValue(
            'FMM_AH_PRODUCTDESCRIPTION_END_CHARACTER',
            '[..]'
        );

        Configuration::updateValue(
            'FMM_AH_PRODUCTDESCRIPTION_COLOR',
            '#7a7a7a'
        );

        return (
            parent::install()
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayProductListReviews')
        );
    }

    public function uninstall()
    {
        Configuration::deleteByName('FMM_AH_PRODUCTDESCRIPTION_NO_OF_CHAR');
        Configuration::deleteByName('FMM_AH_PRODUCTDESCRIPTION_END_CHARACTER');
        Configuration::deleteByName('FMM_AH_PRODUCTDESCRIPTION_ALIGN');
        Configuration::deleteByName('FMM_AH_PRODUCTDESCRIPTION_COLOR');
        Configuration::deleteByName('FMM_AH_PRODUCTDESCRIPTION_ACTIVE');
        return (
            parent::uninstall()
            && $this->unregisterHook('displayHeader')
            && $this->unregisterHook('displayProductListReviews')
        );
    }

    public function renderConfigurationForm()
    {
        $default_lang = (int) Configuration::get('PS_LANG_DEFAULT');
        $form = [
            'form' => [
                'tinymce' => true,
                'legend' => [
                    'title' => $this->l('Settings'),
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Number character description'),
                        'name' => 'no_of_characters',
                        'desc' => $this->l('Please enter number of characters you want to show'),
                    ],

                    [
                        'type' => 'text',
                        'label' => $this->l('Characters End'),
                        'name' => 'end_of_characters',
                    ],

                    [
                        'label' => $this->l('Align'),
                        'type' => 'select',
                        'name' => 'description_align',
                        'options' => [
                            'id' => 'id_align',
                            'name' => 'name',
                            'query' => [
                                [
                                    'id_align' => 'center',
                                    'name' => $this->l('center')
                                ],
                                [
                                    'id_align' => 'left',
                                    'name' => $this->l('left')
                                ],
                                [
                                    'id_align' => 'right',
                                    'name' => $this->l('right')
                                ],
                            ]
                        ]
                    ],
                    
                    [
                        'type' => 'switch',
                        'is_bool' => true,
                        'label' => $this->l('Enable Description'),
                        'name' => 'active',
                        'values' => [
                            [
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Yes'),
                            ],
                            [
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('No'),
                            ],
                        ],
                    ],

                    [
                        'label' => $this->l("Color"),
                        'type' => 'color',
                        'name' => 'description_color'
                    ]

                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        // Module, token and currentIndex
        $helper->module = $this;
        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);

        // Default language
        $helper->default_form_language = $default_lang;

        $helper->allow_employee_form_lang = $default_lang;

        $helper->title = $this->displayName;
        
        $helper->submit_action = 'submitConfigurationForm';

        //**--- Load current value into the form --**//
 
        $helper->fields_value['no_of_characters'] = Tools::getValue(
            'no_of_characters',
            Configuration::get('FMM_AH_PRODUCTDESCRIPTION_NO_OF_CHAR')
        );

        $helper->fields_value['end_of_characters'] = Tools::getValue(
            'end_of_characters',
            Configuration::get('FMM_AH_PRODUCTDESCRIPTION_END_CHARACTER')
        );

        $helper->fields_value['description_color'] = Tools::getValue(
            'description_color',
            Configuration::get('FMM_AH_PRODUCTDESCRIPTION_COLOR')
        );


        $helper->fields_value['description_align'] = Tools::getValue(
            'description_align',
            Configuration::get('FMM_AH_PRODUCTDESCRIPTION_ALIGN')
        );

        $helper->fields_value['active'] = Tools::getValue(
            'active',
            Configuration::get('FMM_AH_PRODUCTDESCRIPTION_ACTIVE')
        );
        return $helper->generateForm([$form]);
    }

    public function __postProcess()
    {
        $output = '';

        if (Tools::isSubmit('submitConfigurationForm')) {
            if (!empty(Tools::getValue('no_of_characters')) and
                ValidateCore::isUnsignedInt(Tools::getValue('no_of_characters'))) {
                Configuration::updateValue(
                    'FMM_AH_PRODUCTDESCRIPTION_NO_OF_CHAR',
                    (int)Tools::getValue('no_of_characters')
                );

                Configuration::updateValue(
                    'FMM_AH_PRODUCTDESCRIPTION_END_CHARACTER',
                    Tools::getValue('end_of_characters')
                );

                Configuration::updateValue(
                    'FMM_AH_PRODUCTDESCRIPTION_ALIGN',
                    Tools::getValue('description_align')
                );

                Configuration::updateValue(
                    'FMM_AH_PRODUCTDESCRIPTION_ACTIVE',
                    Tools::getValue('active')
                );
                
                Configuration::updateValue(
                    'FMM_AH_PRODUCTDESCRIPTION_COLOR',
                    Tools::getValue('description_color')
                );
                
                $output = $this->displayConfirmation($this->l('Setting updated'));
            } else {
                $output = $this->displayError($this->l('Number of character should not be negative or empty'));
            }
        }
        return $output . $this->renderConfigurationForm();
    }

    public function getContent()
    {
        return $this->__postProcess();
    }

    public function hookdisplayHeader($params)
    {
        if (_PS_VERSION_ == '1.7.6.0' or _PS_VERSION_ == '1.7.6') {
            $this->context->controller->registerStylesheet(
                'modules-productdescription',
                'modules/' . $this->name . '/views/css/presta1760.css'
            );
        } elseif (_PS_VERSION_ >= 1.7) {
            $this->context->controller->registerStylesheet(
                'modules-productdescription',
                'modules/' . $this->name . '/views/css/productdescription.css'
            );
            $this->context->controller->registerStylesheet(
                'modules-productdescription',
                'modules/' . $this->name . '/views/css/productdescription.css'
            );
        } else {
            $this->context->controller->addCSS(
                $this->_path.'views/css/productdescription.css'
            );
        }
    }
    
    public function hookDisplayProductListReviews($params)
    {
        $status = Configuration::get(
            'FMM_AH_PRODUCTDESCRIPTION_ACTIVE'
        );

        $limit = Configuration::get(
            'FMM_AH_PRODUCTDESCRIPTION_NO_OF_CHAR'
        );

        $color = Configuration::get(
            'FMM_AH_PRODUCTDESCRIPTION_COLOR'
        );

        $end = Configuration::get(
            'FMM_AH_PRODUCTDESCRIPTION_END_CHARACTER'
        );
        $description = '';
        if ($params['product']['description'] != '') {
            if (_PS_VERSION_ == '1.7.6.0' or _PS_VERSION_ == '1.7.6') {
                $descriptionclear = strip_tags($params['product']['description']);
                $description = Tools::substr($descriptionclear, 0, $limit).$end;
            } else {
                $description = Tools::substr(
                    $params['product']['description'],
                    0,
                    $limit
                ).$end;
            }

            if ($status != 0) {
                $this->context->smarty->assign([
                    'limitdes' => $limit,
                    'description' => $description,
                    'color' => $color,
                    'align' => Configuration::get(
                        'FMM_AH_PRODUCTDESCRIPTION_ALIGN'
                    ),
                    'version' => _PS_VERSION_
                ]);
            } else {
                $this->context->smarty->assign([
                    'description' => null,
                    'color' => null,
                    'align' => null,
                    'version' => _PS_VERSION_
                ]);
            }
        } else {
            $this->context->smarty->assign([
                'description' => 'Description not available',
                'color' => $color,
                'align' => Configuration::get(
                    'FMM_AH_PRODUCTDESCRIPTION_ALIGN'
                ),
                'version' => _PS_VERSION_
            ]);
        }
        return $this->display(__FILE__, 'productdescription.tpl');
    }
}
