<?php
/**
* DISCLAIMER
*
* Do not edit or add to this file.
* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by FME Modules.
*
* @author FMM Modules
* @copyright FMM Modules 2021
* @license Single domain
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class Homecms extends Module
{
    public function __construct()
    {
        $this->name = 'homecms';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'FMM Modules';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.6',
            'max' => '1.7.99',
        ];
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('CMS on Home');
        $this->description = $this->l('Display CMS page on your home page.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }
    /**
     * Install mymodule  
     */
    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return (
            parent::install()
            && $this->registerHook('displayHome')
            && $this->registerHook('header')
        );
    }

    /**
     * Uninstall mymodule
     */
    public function uninstall()
    {
        return (
            parent::uninstall()
        );
    }

    /**
     * this method will call after request to getContent()
     */
    public function postProcess()
    {
        if (Tools::isSubmit('submithomecms')) {
            Configuration::updateValue('homecmscontent', Tools::getValue('homecmscontent'));
        }

        return $this->renderForm();
    }

    /**
     * call with "submit" action
     * 
     * @return string|object
     */
    public function getContent()
    {
        return $this->postProcess();
    }

    /**
     * show data in the list/table form
     * 
     * @return object
     */
    private function renderForm()
    {
        $cms = new CMS();

        $cms = $cms->listCms(Context::getContext()->language->id);

        $default_lang = (int) Configuration::get('PS_LANG_DEFAULT');
        
        $form = [
            'form' => [
                'tinymce' => true,
                'legend' => [
                    'title' => $this->l('Settings'),
                ],
                'input' => [
                    array(
                        'type' => 'select',
                        'label' => $this->l('CMS page on Home:'),
                        'name' => 'homecmscontent',
                        // 'desc' => '<a href="#" class="btn btn-primary">Add CMS</a>',
                        'options' => array(
                            'query' => $cms,
                            'id' => 'id_cms',
                            'name' => 'meta_title'
                        )
                    ),
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        
        $helper->module = $this;

        $helper->title = $this->displayName;
        
        $helper->name_controller = $this->name;
        
        $helper->toolbar_scroll = true;
        
        $helper->show_cancel_button = true;
        
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);
        
        $helper->default_form_language = $default_lang;

        $helper->allow_employee_form_lang = $default_lang;

        $helper->toolbar_scroll = true;

        $helper->fields_value['homecmscontent'] = Tools::getValue(
            'homecmscontent', 
            Configuration::get('homecmscontent')
        );
     
        $helper->submit_action = 'submithomecms';

        return $helper->generateForm([$form]);
    }

     /**
     * Hook/dump/put/display "mymodule" in front-office
     * 
     * @return homecms.tpl
     */
    public function hookDisplayHome() 
    {
        $cms = new CMS(Configuration::get('homecmscontent'), Context::getContext()->language->id, true);

        if ($cms->active != 0) {
            $this->context->smarty->assign([
                'my_module_name' => 'Home CMS',
                'cms' => $cms,
            ]);
        } else {
            $this->context->smarty->assign([
                'my_module_name' => 'Home CMS',
                'cms' => null,
            ]);
        }
        return $this->display(__FILE__, 'homecms.tpl');
    }

    public function hookHeader()
    {
        $this->context->controller->addCSS(($this->_path).'views/css/homecms.css');
    }
}
