<?php
/**
* DISCLAIMER
*
* Do not edit or add to this file.
* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by FME Modules.
*
* @author FMM Modules
* @copyright FMM Modules 2021
* @license Single domain
*/

class CursorEffectCursorEffectConModuleFrontController extends ModuleFrontController
{
    public function displayAjaxInitCursorEffect()
    {
        $shap = Configuration::get('FMM_AH_CURSOREFFECT_SHAP');
        $animation = Configuration::get('FMM_AH_CURSOREFFECT_ANIMATION_TYPE');
        if ($shap == '') {
            echo json_encode([]);
        } else {
            echo json_encode(['shap' => $shap, 'animation' => $animation]);
        }
    }
}
