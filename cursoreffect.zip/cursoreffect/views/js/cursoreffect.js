/**
* DISCLAIMER
*
* Do not edit or add to this file.
* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by FME Modules.
*
* @author FMM Modules
* @copyright FMM Modules 2021
* @license Single domain
*/

function setCursorEffect()
{
    $.ajax({
        url: mp_ajax,
        type: "get",
        dataType: 'json',
        data: {
            ajax: 1,
            action: 'initCursorEffect'
        },
        cache: false,
        success: function(data) {
            if(!Object.entries(data).length == 0){
                cursorTrail({
                    pattern: data.shap,
                    animationType: (data.animation != '') ? data.animation : 'flash'
                });
            }
        },
        error: function(error) {
            console.log('***************************');
            console.log(error);
        }
    });
}

$(window).load(function() {
   setCursorEffect();
});
